HOLOEYE-EMBEDDED is As an open source project, contributions are welcomed of many forms.
Examples of contributions include:
* Code patches
* Suggestion or Implemention of new APIs
* Documentation improvements
* Bug reports and patch reviews