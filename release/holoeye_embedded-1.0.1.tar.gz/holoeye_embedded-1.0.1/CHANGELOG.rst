Version 1.0.1 (2021-11-12)
------------------------
* Minor Bug fix

Version 1.0.0 (2021-11-12)
------------------------

* Changing device address API added.
* numpy array support
* Windows configuration support added.
* Improvement on documention

Version 0.1.0 (2021-10-15)
------------------------

* First release after the conversion to the perf module and move to GitHub
* Included RNDIS and SSH API.
